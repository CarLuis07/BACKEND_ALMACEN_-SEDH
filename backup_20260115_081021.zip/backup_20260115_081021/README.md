# BACKUP COMPLETO - ALMAC�N SEDH

**Fecha de backup:** 2026-01-15 08:10:24

## Contenido del backup:

1. **almacen-backend/** - C�digo fuente completo
   - Todos los archivos Python, HTML, CSS, JS
   - Configuraci�n de la aplicaci�n
   - **Excluidos:** venv/, __pycache__/, .git/

2. **almacen_db.backup** - Base de datos PostgreSQL (formato custom)
   - Base de datos: almacen_db
   - Incluye todas las tablas, triggers, functions, datos

3. **.env.backup** - Variables de entorno (si est� disponible)

4. **README.md** - Este archivo

## Informaci�n del servidor:
- **IP:** 192.168.180.164
- **Usuario:** administrador
- **Backend path:** /opt/almacen-backend
- **Servicio:** almacen-backend (systemd)

## C�mo restaurar en un servidor nuevo:

### 1. Restaurar c�digo backend:
```bash
mkdir -p /opt
cp -r almacen-backend /opt/

cd /opt/almacen-backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 2. Restaurar base de datos:
```bash
# Conectar a PostgreSQL
sudo -u postgres psql

# En PostgreSQL:
CREATE DATABASE almacen_db;
```

Luego restaurar:
```bash
sudo -u postgres pg_restore -Fc -d almacen_db almacen_db.backup
```

### 3. Configurar variables de entorno:
```bash
cp .env.backup /opt/almacen-backend/.env
# Editar y ajustar seg�n el nuevo servidor
```

### 4. Iniciar el servicio:
```bash
sudo systemctl enable almacen-backend
sudo systemctl start almacen-backend
```

## Informaci�n t�cnica:

- **Backend:** Python 3.12 + FastAPI + SQLAlchemy
- **Base de datos:** PostgreSQL
- **Servidor web:** Uvicorn
- **Frontend:** HTML5 + JavaScript + Bootstrap

## Versi�n del c�digo:

El c�digo incluye todos los cambios hasta la fecha del backup.
Consulta el archivo git log si necesitas informaci�n de commits espec�ficos.

---
**Generado autom�ticamente**
